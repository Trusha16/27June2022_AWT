$(document).ready(function(){
    $("#id1").draggable();

    $("#id2 span").draggable({
        containment:"#id2"
    });
    $("#id3").draggable({
        axis:"x"
    });
    $("#id4").draggable({
        axis:"y"
    });
    $("#id5 span").draggable({
        distance: 200
     });
     $("#id6 span").draggable({
         delay:3000
     });

 });