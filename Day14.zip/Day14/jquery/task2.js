$(document).ready(function () {
  $("#ageslider").slider({
    min: 18,
    max: 100,
    value: 18,
    slide: function (event, ui) {
      $("#age").val(ui.value);
    }
  });
     $("#age").val($("#ageslider").slider("value"));
     $("#priceslider").slider({
      min: 1,
    max: 500,
    Range: true,
    values: [1, 50],

    start: function (event, ui) {
      $("#start")
        .val("$" + ui.values[0]);
    },

    stop: function (event, ui) {
      $("#end")
        .val("$" + ui.values[1]);
    },

    change: function (event, ui) {
      $("#change").val("$" + ui.values[0] + "-$" + ui.values[1]);
    },

    slide: function (event, ui) {
      $("#slide")
        .val("$" + ui.values[0] + "-$" + ui.values[1]);
    },

  });


});