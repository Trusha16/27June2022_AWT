$(document).ready(function(){
   $("#mainbox").tabs();
});