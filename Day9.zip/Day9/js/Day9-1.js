
function img2(){
    document.getElementById('id1').src=("../css/pexels-mike-fox-4713289.jpg");
}
function img3(){
    document.getElementById('id1').src=("../css/pexels-mike-fox-5550998.jpg");
}
function img4(){
    document.getElementById('id1').src=("../css/pexels-mohan-reddy-3369214.jpg");
}



