function butn11(){
  document.getElementById('id1').style.fontFamily="Impact,charcoal";
  document.getElementById('id1').style.color="red";
  document.getElementsByClassName('btn1').style.backgroundColor="yellow";
}
function butn12(){
  document.getElementById('id1').style.fontSize="50px";
}
function butn13(){
  document.getElementById('id1').style.display="none";
}