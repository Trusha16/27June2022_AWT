$(document).ready(function () {
    $("#main").resizable();

    /*for soarting function*/
    $("#sort-1").sortable();
    $("#sort-2").sortable();

    $("#sort-1").sortable({
        connectWith: "#sort-2, #sort-1"
    });
    $("#sort-2").sortable({
        connectWith: "#sort-1, #sort-2"
    });

});

