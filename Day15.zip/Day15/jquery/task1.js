$(document).ready(function(){
    $("#p1").draggable();
     $("#p2").droppable({
    accept: "#p1",
    drop:function(event,ui){
    
    $(this).addClass("MyCls").find("p").html("Ohkk Done...!!")}
    });
});