function onchng1(){
    document.getElementById('c1').style.backgroundColor="lightpink";
}

$(document).ready(function(){
    
    $("#btn1").click(function(){
        $("#c1").css("background-color","rgb(13, 13, 146)");
        $("#c2").hide();
        $("#c3").hide();
        $("#btn1").click(function (){
            alert("Wanna Show Other Boxes..??");
            $("#c2").show();
            $("#c3").show();
        });
    });
$("#btn2").click(function(){
    $("#c2").css("background-color","rgb(13, 13, 146)");
        $("#c1").hide();
        $("#c3").hide();
        $("#btn2").click(function (){
            alert("Wanna Show Other Boxes..??");
            $("#c1").show();
            $("#c3").show();
        });
    });
    $("#btn3").click(function(){
        $("#c2").css("background-color","rgb(13, 13, 146)");
        $("#c2").hide();
        $("#c1").hide();
        $("#btn3").click(function (){
            alert("Wanna Show Other Boxes..??");
            $("#c2").show();
            $("#c1").show();
        });
    });
});