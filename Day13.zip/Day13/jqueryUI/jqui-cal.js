$(document).ready(function () {
    //*for date picker*//
    $("#id1").datepicker({
        shoewweek: true,
        yearSuffix: "-CE",   
        showAnim: "slide"
    });

    $(function () {
        $("#id2").datepicker();
    });

//*for descriptin box*//
    $("#d1").dialog({
        autoOpen: true,
    });
    $("#btn1").click(function () {
        $("#d1").dialog(open);
    });
});