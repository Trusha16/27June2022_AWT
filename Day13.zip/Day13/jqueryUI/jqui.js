$(document).ready(function () {
    $("#maincontainer1").accordion();
    $("#maincontainer2").accordion();
});