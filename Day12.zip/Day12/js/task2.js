//Reg Ex Declaration - Globaly.
			var $FNameLNameRegEx = /^([a-zA-Z]{2,20})$/;
			var $FullNameRegEx = /^([a-zA-Z ]{2,40})$/;
			var $BankAccountNameRegEx = /^([a-zA-Z ]{2,60})$/;
			var $PasswordRegEx = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,12}$/;

			var $EmailIdRegEx = /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,8}\b$/i;
			var $ConNoRegEx = /^([0-9]{10})$/;
			var $AgeRegEx = /^([0-9]{1,2})$/;
			var $AadhaarNoRegEx = /^([0-9]{12})$/;
			var $GSTNoRegEx=/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
			var $IndianDrivingLicenseNoRegEx = /^([A-Z]{2,3}[-/0-9]{8,13})$/;
			var $IndianVehicleRegNoRegEx = /^([A-Z]{2}[0-9]{1,2}[A-Z]{1,3}[0-9]{1,4})$/;
			var $PincodeRegEx = /^[1-9][0-9]{5,6}$/;
			var $PANNoRegEx = /^[A-Z]{3}[ABCFGHLJPT][A-Z][0-9]{4}[A-Z]$/;
			var $IFSCCodeRegEx = /^[A-Za-z]{4}0[A-Z0-9a-z]{6}$/;
			var $BankAccountNoRegEx = /^([0-9]{9,18})$/;
			var $LatitudeLongitude=/^(-?(?:1[0-7]|[1-9])?\d(?:\.\d{1,8})?|180(?:\.0{1,8})?)$/;


$(document).ready(function(){
   
    $("#id11").blur(function(){
        $(this).css("background-color","lightpink");
        $("#namevalidation").empty();
        if($(this).val()=="" || $(this).val()==null){
            $("#namevalidation").html("(*) Name is required..!!");
        }
        else{
            if(!$(this).val().match($FullNameRegEx)){
                $("#namevalidation").html("(*) Invalid name..!!");
            }
        }
    });

    $("#id11").keypress(function(){
        $(this).css("background-color","red");
        $("#namevalidation").empty();
        var Flag=((e.which>=65 && e.which<=90) || (e.which>=97 && e.which<=121));
					if(Flag==false){
						$("#namevalidation").html("Invalid Input..!!");
					}
					return Flag;
    });

    $("#id12").blur(function(){
        $(this).css("background-color","lightblue");
        $("#NOvaludation").empty();
        if($(this).val()=="" || $(this).val()==null){
            $("#NOvaludation").html("(*) Contact no. required..!!");
        }
        else{
            if(!$(this).val().match($ConNoRegEx)){
                $("#NOvaludation").html("(*) Invalid contact no..!!");
            }
        }
    });
    
    $("#id12").keypress(function(){
        $(this).css("background-color","red");
        $("#NOvaludation").empty();
        var Flag=(e.which>=48 && e.which<=57);
					if(Flag==false){
						$("#NOvaludation").html("Invalid Input..!!");
					}
					return Flag;
    });

    $("#id13").blur(function(){
        $(this).css("background-color","lightgreen");
        $("#mailvalidation").empty();
        if($(this).val()=="" || $(this).val()==null){
            $("#mailvalidation").html("(*) Email id is required..!!");
        }
        else{
            if(!$(this).val().match($EmailIdRegEx)){
                $("#mailvalidation").html("(*) Invalid email id..!!");
            }
        }
    });

    $("#id14").blur(function(){
        $(this).css("background-color","yellow");
        $("#addrsvalidation").empty();
        if($(this).val()=="" || $(this).val()==null){
            $("#addrsvalidation").html("(*) Address is required..!!");
        }
            else{
                if($("#id14").val().length>300){
                    $("#addrsvalidaton").html("(*) Invalid contact message..!!");
                }
            }
    
    });

var TxtNameFlag=false,TxtContactNoFlag=false,TxtEmailIdFlag=false,TxtContactMsgFlag=false;
   
    $("#Sbmt").click(function(){
        $(this).css("background-color","tomato");

        $("#namevalidation").empty();
        if($("#id11").val()=="" || $("#id11").val()==null){
            $("#namevalidation").html("(*) Name is required..!!");
            TxtNameFlag=false;
        }
        else{
            if(!$("#id11").val().match($FullNameRegEx)){
                $("#namevalidation").html("(*) Invalid name..!!");
                TxtNameFlag=false;
            }
            else{
                TxtNameFlag=true;
            }
        }
        $("#NOvaludation").empty();
        if($("#id12").val()=="" || $("#id12").val()==null){
            $("#NOvaludation").html("(*) Contact no. required..!!");
            TxtContactNoFlag=false;
        }
        else{
            if(!$("#id12").val().match($ConNoRegEx)){
                $("#NOvaludation").html("(*) Invalid contact no..!!");
                TxtContactNoFlag=false;
            }
            else{
                TxtContactNoFlag=true;
            }
        }
        $("#mailvalidation").empty();
        if($("#id13").val()=="" || $("#id13").val()==null){
            $("#mailvalidation").html("(*) Email id is required..!!");
            TxtEmailIdFlag=false;
        }
        else{
            if(!$("#id13").val().match($EmailIdRegEx)){
                $("#mailvalidation").html("(*) Invalid Mail id..!!");
                TxtEmailIdFlag=false;
            }
            else{
                TxtEmailIdFlag=true;
            }
        }
        $("#addrsvalidation").empty();
        if($("#id14").val()=="" || $("#id14").val()==null){
            $("#addrsvalidation").html("(*) Address is required..!!");
            TxtContactMsgFlag=false;
        }
        else{
            if($("#id14").val().length>300){
                $("#addrsvalidation").html("(*) Invalid Address..!!");
                TxtContactMsgFlag=false;
            }
            else{
                TxtContactMsgFlag=true;
            }
        }
        if(TxtNameFlag==true && TxtContactNoFlag==true && TxtEmailIdFlag==true && TxtContactMsgFlag==true){
            $(this).css("background-color","lightblue");
            $("input,textarea").val("");
            alert("Form submitted successfully");
        }
        else{
            alert("Fill all information..");
        }
    });

});