$(document).ready(function (){
 $("#id1").click(function(){
     alert("it will focus this button!!");
     });
     $("#id1").focus(function(){
    $(this).css("background-color","pink");
 });
    
 $("#id2").blur(function(){
        $(this).css("background-color","red");
    });
$("#id3").keypress(function(){
        alert($(this).val());
    });
$("#id4").keyup(function(){
        alert($(this).val());
    });
 });
 